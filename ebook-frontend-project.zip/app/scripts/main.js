'use strict';

(function() {
  console.log('hola mundo!');
})();
